#!/bin/sh

#dports pkg
pkg install -y $*

